package us.hourgeon.jmessenger.client;

public interface MessageEvents {
    void onMessage(String message);
}
